import { View, Text, FlatList, Image } from 'react-native';

const players = [
  { id: '1', name: 'Mario Rossi', photo: null },
  { id: '2', name: 'Luca Bianchi', photo: null },
];

export default function Giocatori() {
  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold' }}>Giocatori</Text>
      <FlatList
        data={players}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={{ marginVertical: 10 }}>
            <Text style={{ fontSize: 18 }}>{item.name}</Text>
            {item.photo ? (
              <Image source={{ uri: item.photo }} style={{ width: 100, height: 100 }} />
            ) : null}
          </View>
        )}
      />
    </View>
  );
}